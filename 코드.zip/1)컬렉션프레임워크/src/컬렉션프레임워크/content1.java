package 컬렉션프레임워크;

import java.util.ArrayList;
import java.util.List;

public class content1 {
	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		
		
		//ArrayList에 string 객체를 저장
		list.add("<오징어 게임> 글로벌 신드롬");
		list.add("K-Pop 혼종성 강화, 팬덤 공고화");
		list.add("코로나19 팬데믹 장기화에 따른 한류콘텐츠 소비 확대");
		list.add("한류 대중화 확대");
		list.add("방탄소년단 이후의 K-Pop, 그리고 한류");
		list.add("영국 옥스퍼드 사전에 실린 한국어 단어");
		list.add("기타");
		//
		
		
		//저장된 총 객체 수 얻기
		int size = list.size();
		System.out.println();
		System.out.println("CONTENT. 연간 주요 한류 이슈");		
		System.out.println();
		
		//저장된 총 객체수만큼 루핑 후 출력
		for(int i=0; i<list.size(); i++) {
			String str = list.get(i);
			System.out.println("ISSUE" + (i+1) + "." + str);
		}
		System.out.println();
				
		
	}
}
