package 다형성상속;


//자식 클래스
class content1 extends title4 {
	// 메소드 오버라이딩
	public void draw() { 	
		System.out.println("-한류지수 증가");
	}
}

class content2 extends title4 {
	// 메소드 오버라이딩
	public void draw() { 
		System.out.println("-한류 이용확산지표 증가");
	}
}

class content3 extends title4 {
	// 메소드 오버라이딩
	public void draw() { 	
		System.out.println("-성별, 연령별 한류콘텐츠 이용량 격차 감소");
	}
}
//여기까지 자식클래스

class title4 {
	
	public void draw() {
		System.out.println("ISSUE 4. 한류 대중화 확대(다형성)");
		System.out.println("");
	}
}


public class Issue4 {
	public static void main(String[] args) {

		paint(new title4());   	// title4 s = new title4();
		paint(new content1());     	// title4 s = new content1();
		paint(new content2()); 	// title4 s = new content2();
		paint(new content3());   	// title4 s = new content3();
		
	}

	public static void paint(title4 s) {
		s.draw();         // s 객체 내에 오버라이딩된 draw() 호출 
	}
}