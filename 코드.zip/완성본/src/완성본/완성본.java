package 완성본;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



public class 완성본 {
	public static void main(String[] args) throws IOException{
	///Introduce///
		BoardDao dao = new BoardDao();
		List<Board> list = dao.getBoardList();
		System.out.println("[2022 글로벌 한류 트렌드]");
		System.out.println();
		for(Board board : list) {
			System.out.println(board.getTitle() + ":" + board.getContent());
		}
      	System.out.println("---------------------------------------------------------------------------------------------");
		
	///content1///
		List<String> listA = new ArrayList<String>();
		
		
		//ArrayList에 string 객체를 저장
		listA.add("<오징어 게임> 글로벌 신드롬");
		listA.add("K-Pop 혼종성 강화, 팬덤 공고화");
		listA.add("코로나19 팬데믹 장기화에 따른 한류콘텐츠 소비 확대");
		listA.add("한류 대중화 확대");
		listA.add("방탄소년단 이후의 K-Pop, 그리고 한류");
		listA.add("영국 옥스퍼드 사전에 실린 한국어 단어");
		listA.add("기타");
		//
		
		
		//저장된 총 객체 수 얻기
		int size = list.size();
		System.out.println();
		System.out.println("CONTENT. 연간 주요 한류 이슈");		
		System.out.println();
		
		//저장된 총 객체수만큼 루핑 후 출력
		for(int i=0; i<listA.size(); i++) {
			String str = listA.get(i);
			System.out.println("ISSUE" + (i+1) + "." + str);
		}
		System.out.println();
      	System.out.println("---------------------------------------------------------------------------------------------");
		
	///Issue1///
		TitlePoint cp = new TitlePoint("<오징어 게임> 각종 흥행 지표와 인기 요인 분석", "<오징어 게임> 이후의 한국 영상콘텐츠 흥행 현황과 전망", "ISSUE 1. <오징어 게임> 글로벌 신드롬");
		cp.showTitlePoint();
		System.out.println();
		
		//데이터 출발지를 "ISSUE1 오징어 게임 글로벌 신드롬.txt"로 하는 문자기반 파일 입력스트림 생성
		FileReader reader = new FileReader("D:/대학교 2학년/2학기/객체지향프로그래밍/과제/텍스트파일/ISSUE1 오징어 게임 글로벌 신드롬.txt");
        int ch;
        
        //파일 전체를 읽고 출력
        while ((ch = reader.read()) != -1) {
            System.out.print((char) ch);
        }
        //입력스트림 닫음
        reader.close();
        System.out.println();
      	System.out.println("---------------------------------------------------------------------------------------------");
		
    ///Issue2///    
        //데이터 출발지를 "ISSUE2 K-Pop 혼종성 강화, 팬덤 공고화.txt"로 하는 문자기반 파일 입력스트림 생성
        FileReader reader1 = new FileReader("D:/대학교 2학년/2학기/객체지향프로그래밍/과제/텍스트파일/ISSUE2 K-Pop 혼종성 강화, 팬덤 공고화.txt");
        int ch1;
        
        //파일 전체를 읽고 출력
        while ((ch1 = reader1.read()) != -1) {
            System.out.print((char) ch1);
        }
        
        //입력스트림 닫음
        reader1.close();
        
        System.out.println();
      	System.out.println("---------------------------------------------------------------------------------------------");
		
    ///Issue3///
        title2Test oc = new title2Ex();
		oc.title2();
		oc.Content1();
		oc.Content2(4.2);
		oc.Content3(3.1);
		
		System.out.println();
      	System.out.println("---------------------------------------------------------------------------------------------");
		
    ///Issue4///
        paint(new title4());   	// title4 s = new title4();
		paint(new content1());     	// title4 s = new content1();
		paint(new content2()); 	// title4 s = new content2();
		paint(new content3());   	// title4 s = new content3();
        
		System.out.println();
      	System.out.println("---------------------------------------------------------------------------------------------");
		
    ///Issue5///
        Contents Contents = new Contents();
		
		ContentA1 contentA1 = new ContentA1();
		ContentA2 contentA2 = new ContentA2();
		
		System.out.print("ISSUE 5. 방탄소년단 이후의 K-Pop, 그리고 한류");
		System.out.println();
		System.out.println();
		Contents.Content(contentA1);
		Contents.Content(contentA2);
		
    	//데이터 출발지를 "ISSUE5 방탄소년단 이후의 K-Pop, 그리고 한류.txt"로 하는 문자기반 파일 입력스트림 생성
		FileReader reader2 = new FileReader("D:/대학교 2학년/2학기/객체지향프로그래밍/과제/텍스트파일/ISSUE5 방탄소년단 이후의 K-Pop, 그리고 한류.txt");
		int ch2;
		
		//파일 전체를 읽고 출력
		while ((ch2 = reader2.read()) != -1) {
            System.out.print((char) ch2);
        }
        
        //입력스트림 닫음
        reader2.close();
        
        System.out.println();
      	System.out.println("---------------------------------------------------------------------------------------------");
		
    ///Issue6///
      //배열을 이용하여 LoginResult의 value 갑을 모두 가져옴
      	LoginResult[] results = LoginResult.values();
      	System.out.print("ISSUE 6. 영국 옥스퍼드 사전에 실린 한국어 단어");
      	System.out.println();
      	System.out.println();
      	
      	//반복문을 돌려 result와 동일하면 값을 출력
      	for(LoginResult result : results){
      		if(result == LoginResult.banchan) {System.out.println(result + " - 전형적인 한국 식사의 일부분으로, 밥과 함께 제공되는 작은 곁들임 요리");
      		} else if(result == LoginResult.bulgogi) {System.out.println(result + " - 한국 요리: 쇠고기나 돼지고기를 얇게 썰어 양념에 재운 다음 굽거나 볶는 요리");
      		} else if(result == LoginResult.kimbap) {System.out.println(result + " - 밥과 각종 재료를 김 한 장에 싸서 먹기 좋은 크기로 자른 한식");
      		} else if(result == LoginResult.hallyu) {System.out.println(result + " - 한국의 음악, 영화, TV, 패션, 음식 등의 세계적인 성공으로 한국과 대중문화에 관한 국제적 관심 증가 현상");
      		} else if(result == LoginResult.Kdrama) {System.out.println(result + " - 한국에서 제작된 한국어 TV 시리즈");
      		} else if(result == LoginResult.manhwa) {System.out.println(result + " - 보통 일본 망가(manga)의 영향을 받은 한국의 만화 장르");
      		} else if(result == LoginResult.mukbang) {System.out.println(result + " - 한 사람이 많은 양의 음식을 먹고 시청자들과 이야기하는 모습을 생중계하는 영상");
      		}
      	}
      	
      	System.out.println();
      	System.out.println("---------------------------------------------------------------------------------------------");
		
    ///Issue7///
        //예외처리
      	System.out.print("ISSUE 7. 기타");
      	System.out.println();

        try {
			findClass();
		}catch(ClassNotFoundException e) {
			System.out.println("'java,lang.String2'라는 클래스가 존재하지 않습니다.");
			System.out.println("한류에 대한 내용이 없습니다.");
		}
        System.out.println();
      	System.out.println("---------------------------------------------------------------------------------------------");
		
        
        //파일입출력
        //File 객체생성
      	File file1 = new File("D:/대학교 2학년/2학기/객체지향프로그래밍/과제/ISSUE1 오징어 게임 글로벌 신드롬.txt");
      	File file2 = new File("D:/대학교 2학년/2학기/객체지향프로그래밍/과제/ISSUE2 K-Pop 혼종성 강화, 팬덤 공고화.txt");
      	File file3 = new File("D:/대학교 2학년/2학기/객체지향프로그래밍/과제/ISSUE5 방탄소년단 이후의 K-Pop, 그리고 한류.txt");
      		
      	//파일 또는 폴더가 존재하지 않으면 생성
      	if(file1.exists() == false) {  file1.createNewFile();  }
      	if(file2.exists() == false) {  file2.createNewFile();  }
      	if(file3.exists() == false) {  file3.createNewFile();  }

      		
      	//"D:/대학교 2학년/2학기/객체지향프로그래밍/과제/텍스트파일" 폴더의 내용 목록을 file 배열로 얻음
      	File temp = new File("D:/대학교 2학년/2학기/객체지향프로그래밍/과제/텍스트파일");
      	File[] contents = temp.listFiles();
      	
      	System.out.println("시간\t\t\t형태\t\t크기\t이름");
      	System.out.println("---------------------------------------------------------------------------------------------");
      	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd a HH:mm");
      	for(File file : contents) {
      		//파일 또는 폴더 정보를 출력
      		System.out.print(sdf.format(new Date(file.lastModified())));
      		if(file.isDirectory()) {
      			System.out.print("\t<DIR>\t\t\t" + file.getName());
      		} else {
      			System.out.print("\t\t\t" + file.length() + "\t" + file.getName());
      		}
       		System.out.println();
      	}
      	
        
	
	}
	///Issue4///
	public static void paint(title4 s) {
		s.draw();         // s 객체 내에 오버라이딩된 draw() 호출 
	}
	
	//예외처리//
	public static void findClass() throws ClassNotFoundException{
		//findClass();
		Class clazz = Class.forName("java,lang.String2");
	}
}

///Introduce///
class Board {
	private String title;
	private String content;
	
	public Board(String title, String content) {
		this.title = title;
		this.content = content;
	}

	public String getTitle() { return title; }
	public String getContent() { return content; }
}

class BoardDao {
	public List<Board> getBoardList() {
		List<Board> list = new ArrayList<Board>();
		list.add(new Board("이름", "김미영"));
		list.add(new Board("학번", "202100573"));
		list.add(new Board("학과", "컴퓨터공학부"));
		return list;
	}
}
///---------///


///Issue1///

class Point {
	private String x, y; // 소제목(issue1)을 구성하는 x, y 좌표
	
	public Point(String x, String y) {
		this.x = x; 
		this.y = y;
	}
	
	public void showPoint() { // 점의 좌표 출력
		System.out.println("-" + x);
		System.out.println("-" + y);
	}
}

class TitlePoint extends Point { 
	private String Title1; // 소제목

	public TitlePoint(String x, String y, String Title1) {
		super(x, y); // Point의 생성자 Point(x, y) 호출
		this.Title1 = Title1;
	}
	
	public void showTitlePoint() { // 소제목 점의 좌표 출력
		System.out.print(Title1);
		System.out.println();
		System.out.println();
		showPoint(); 	// Point 클래스의 showPoint() 호출 
	}
}
///---------///




///Issue3///

interface title2Test {
	//추상 메소드
  	void title2();
	void Content1();
	void Content2(double num2);
	void Content3(double num3);
}

class title2Ex implements title2Test {
	public void title2() {
		System.out.println("ISSUE 3. 코로나19 팬데믹 장기화에 따른 한류콘텐츠 소비 확대");
		System.out.println();
	}

	public void Content1() {
		System.out.println("-전년 대비 한류콘텐츠 소비량 증가");
	}

	public void Content2(double num2) {
		System.out.println("-드라마 호감도 전년 대비 " + num2 + "% 상승");
	}

	public void Content3(double num3) {
		System.out.println("-한류콘텐츠 브랜드 파워 지수(BPI) 전년 대비 " + num3 + "점 상승");
	}
}

///---------///


///Issue4///
//자식 클래스
class content1 extends title4 {
	// 메소드 오버라이딩
	public void draw() { 	
		System.out.println("-한류지수 증가");
	}
}

class content2 extends title4 {
	// 메소드 오버라이딩
	public void draw() { 
		System.out.println("-한류 이용확산지표 증가");
	}
}

class content3 extends title4 {
	// 메소드 오버라이딩
	public void draw() { 	
		System.out.println("-성별, 연령별 한류콘텐츠 이용량 격차 감소");
	}
}
//여기까지 자식클래스

class title4 {
	
	public void draw() {
		System.out.println("ISSUE 4. 한류 대중화 확대(다형성)");
		System.out.println("");
	}
}
///---------///

///Issue5///

//매개 변수를 인터페이스화
class Contents {
	public void Content(ContentTest ContentTest) {
		ContentTest.run();
	}
}

//인터페이스
interface ContentTest {
	public void run();
}

//구현 클래스
class ContentA1 implements ContentTest {
	@Override
	public void run() {
		System.out.println("-방탄소년단 그룹 활동 잠정 중단");
	}
}

//구현 클래스
class ContentA2 implements ContentTest {
	@Override
	public void run() {
		System.out.println("-K-Pop과 한류의 미래");
	}
}
///---------///

///Issue6///
//열거 선언
enum LoginResult {
	banchan,
	bulgogi,
	kimbap,
	hallyu,
	Kdrama,
	manhwa,
	mukbang
}

///---------///

///Issue7///
///---------///

