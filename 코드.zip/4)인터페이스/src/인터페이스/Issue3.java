package 인터페이스;

// Issue3 인터페이스를 구현한 구현 클래스를 Issue3와 관련된 내용을 출력하도록 작성하였다.

interface title2Test {
	//추상 메소드
  	void title2();
	void Content1();
	void Content2(double num2);
	void Content3(double num3);
}

class title2Ex implements title2Test {
	public void title2() {
		System.out.println("ISSUE 3. 코로나19 팬데믹 장기화에 따른 한류콘텐츠 소비 확대");
		System.out.println();
	}

	public void Content1() {
		System.out.println("-전년 대비 한류콘텐츠 소비량 증가");
	}

	public void Content2(double num2) {
		System.out.println("-드라마 호감도 전년 대비 " + num2 + "% 상승");
	}

	public void Content3(double num3) {
		System.out.println("-한류콘텐츠 브랜드 파워 지수(BPI) 전년 대비 " + num3 + "점 상승");
	}
}


public class Issue3 {

	public static void main(String[] args) {
		title2Test oc = new title2Ex();
		oc.title2();
		oc.Content1();
		oc.Content2(4.2);
		oc.Content3(3.1);
		
	}
}