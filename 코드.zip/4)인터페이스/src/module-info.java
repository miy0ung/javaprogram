/**
 * 
 */
/**
 * @author 김미영
 *
 */
module 인터페이스 {
}