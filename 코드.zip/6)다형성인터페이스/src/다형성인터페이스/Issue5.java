package 다형성인터페이스;

import java.io.FileReader;
import java.io.IOException;

//매개 변수를 인터페이스화
class Contents {
	public void Content(ContentTest ContentTest) {
		ContentTest.run();
	}
}

//인터페이스
interface ContentTest {
	public void run();
}

//구현 클래스
class Content1 implements ContentTest {
	@Override
	public void run() {
		System.out.println("-방탄소년단 그룹 활동 잠정 중단");
	}
}

//구현 클래스
class Content2 implements ContentTest {
	@Override
	public void run() {
		System.out.println("-K-Pop과 한류의 미래");
	}
}

//매개 변수의 다형성 테스트
public class Issue5 {
	public static void main(String[] args) throws IOException {
		Contents Contents = new Contents();
		
		Content1 content1 = new Content1();
		Content2 content2 = new Content2();
		
		System.out.print("ISSUE 5. 방탄소년단 이후의 K-Pop, 그리고 한류");
		System.out.println();
		System.out.println();
		Contents.Content(content1);
		Contents.Content(content2);
		
    	//데이터 출발지를 "ISSUE5 방탄소년단 이후의 K-Pop, 그리고 한류.txt"로 하는 문자기반 파일 입력스트림 생성
		FileReader reader = new FileReader("D:/대학교 2학년/2학기/객체지향프로그래밍/과제/텍스트파일/ISSUE5 방탄소년단 이후의 K-Pop, 그리고 한류.txt");
		int ch;
		
		//파일 전체를 읽고 출력
		while ((ch = reader.read()) != -1) {
            System.out.print((char) ch);
        }
        
        //입력스트림 닫음
        reader.close();
	}
}



