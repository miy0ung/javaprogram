package 열거타입;


public class Issue6 {
	public static void main(String[] args) {
		//배열을 이용하여 LoginResult의 value 갑을 모두 가져옴
		LoginResult[] results = LoginResult.values();
		System.out.print("ISSUE 6. 영국 옥스퍼드 사전에 실린 한국어 단어");
		System.out.println();
		System.out.println();
		
		//반복문을 돌려 result와 동일하면 값을 출력
		for(LoginResult result : results){
			if(result == LoginResult.banchan) {System.out.println(result + " - 전형적인 한국 식사의 일부분으로, 밥과 함께 제공되는 작은 곁들임 요리");
			} else if(result == LoginResult.bulgogi) {System.out.println(result + " - 한국 요리: 쇠고기나 돼지고기를 얇게 썰어 양념에 재운 다음 굽거나 볶는 요리");
			} else if(result == LoginResult.kimbap) {System.out.println(result + " - 밥과 각종 재료를 김 한 장에 싸서 먹기 좋은 크기로 자른 한식");
			} else if(result == LoginResult.hallyu) {System.out.println(result + " - 한국의 음악, 영화, TV, 패션, 음식 등의 세계적인 성공으로 한국과 대중문화에 관한 국제적 관심 증가 현상");
			} else if(result == LoginResult.Kdrama) {System.out.println(result + " - 한국에서 제작된 한국어 TV 시리즈");
			} else if(result == LoginResult.manhwa) {System.out.println(result + " - 보통 일본 망가(manga)의 영향을 받은 한국의 만화 장르");
			} else if(result == LoginResult.mukbang) {System.out.println(result + " - 한 사람이 많은 양의 음식을 먹고 시청자들과 이야기하는 모습을 생중계하는 영상");
			}
		}
	}
}

//열거 선언
enum LoginResult {
	banchan,
	bulgogi,
	kimbap,
	hallyu,
	Kdrama,
	manhwa,
	mukbang
}
