/**
 * 
 */
/**
 * @author 김미영
 *
 */
module 클래스상속 {
}